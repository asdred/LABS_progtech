<div>
    <div>
        <h2>Организации</h2>
    </div>
    <div>
        <?php echo $this->tag->linkTo(array('organization/new', 'Создать', 'class' => 'btn btn-primary')); ?>
    </div>
</div>

<?php $v108009657487271256711iterated = false; ?><?php $v108009657487271256711iterator = $page->items; $v108009657487271256711incr = 0; $v108009657487271256711loop = new stdClass(); $v108009657487271256711loop->length = count($v108009657487271256711iterator); $v108009657487271256711loop->index = 1; $v108009657487271256711loop->index0 = 1; $v108009657487271256711loop->revindex = $v108009657487271256711loop->length; $v108009657487271256711loop->revindex0 = $v108009657487271256711loop->length - 1; ?><?php foreach ($v108009657487271256711iterator as $organizations) { ?><?php $v108009657487271256711loop->first = ($v108009657487271256711incr == 0); $v108009657487271256711loop->index = $v108009657487271256711incr + 1; $v108009657487271256711loop->index0 = $v108009657487271256711incr; $v108009657487271256711loop->revindex = $v108009657487271256711loop->length - $v108009657487271256711incr; $v108009657487271256711loop->revindex0 = $v108009657487271256711loop->length - ($v108009657487271256711incr + 1); $v108009657487271256711loop->last = ($v108009657487271256711incr == ($v108009657487271256711loop->length - 1)); ?><?php $v108009657487271256711iterated = true; ?>
<?php if ($v108009657487271256711loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th class="hidden">id</th>
            <th>Название</th>
            <th>Адрес</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($organizations->del == 0) { ?>
    <tbody>
        <tr>
            <td class="hidden"><?php echo $organizations->id; ?></td>
            <td><?php echo $organizations->name; ?></td>
            <td><?php echo $organizations->address; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('organization/edit/' . $organizations->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('organization/delete/' . $organizations->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v108009657487271256711loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('organization/index/', '<i class="icon-fast-backward"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('organization/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('organization/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('organization/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v108009657487271256711incr++; } if (!$v108009657487271256711iterated) { ?>
    No companies are recorded
<?php } ?>


