<div>
    <div>
        <h2>Склады</h2>
    </div>
    <div>
        <?php echo $this->tag->linkTo(array('store/new', 'Создать', 'class' => 'btn btn-primary')); ?>
    </div>
</div>

<?php $v148411225324669292471iterated = false; ?><?php $v148411225324669292471iterator = $page->items; $v148411225324669292471incr = 0; $v148411225324669292471loop = new stdClass(); $v148411225324669292471loop->length = count($v148411225324669292471iterator); $v148411225324669292471loop->index = 1; $v148411225324669292471loop->index0 = 1; $v148411225324669292471loop->revindex = $v148411225324669292471loop->length; $v148411225324669292471loop->revindex0 = $v148411225324669292471loop->length - 1; ?><?php foreach ($v148411225324669292471iterator as $stores) { ?><?php $v148411225324669292471loop->first = ($v148411225324669292471incr == 0); $v148411225324669292471loop->index = $v148411225324669292471incr + 1; $v148411225324669292471loop->index0 = $v148411225324669292471incr; $v148411225324669292471loop->revindex = $v148411225324669292471loop->length - $v148411225324669292471incr; $v148411225324669292471loop->revindex0 = $v148411225324669292471loop->length - ($v148411225324669292471incr + 1); $v148411225324669292471loop->last = ($v148411225324669292471incr == ($v148411225324669292471loop->length - 1)); ?><?php $v148411225324669292471iterated = true; ?>
<?php if ($v148411225324669292471loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th class="hidden">id</th>
            <th>Владелец</th>
            <th>Название</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($stores->del == 0) { ?>
    <tbody>
        <tr>
            <td class="hidden"><?php echo $stores->id; ?></td>
            <td><?php echo $stores->owner->name; ?></td>
            <td><?php echo $stores->name; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('store/edit/' . $stores->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('store/delete/' . $stores->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v148411225324669292471loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('store/index/', '<i class="icon-fast-left"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('store/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('store/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('store/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v148411225324669292471incr++; } if (!$v148411225324669292471iterated) { ?>
    No companies are recorded
<?php } ?>

