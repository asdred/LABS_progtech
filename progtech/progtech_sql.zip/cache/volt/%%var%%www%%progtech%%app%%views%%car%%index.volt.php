<div>
    <div>
        <h2>Автомобили <?php echo $status; ?></h2>
    </div>
    <div>
        <div style="text-align: left">
            <?php echo $this->tag->form(array('car/index')); ?>
                <input type="radio" name="capacity" value="max">Наиболее грузоподъёмный</inpu><br>
                <input type="radio" name="capacity" value="min">Наименее грузоподъёмный</inpu><br>
                <?php echo $this->tag->submitButton(array('Фильтр', 'class' => 'btn btn-primary')); ?>
            </form>
        </div>
        <?php echo $this->tag->linkTo(array('car/new', 'Создать', 'class' => 'btn btn-primary')); ?>
    </div>
</div>


<?php $v122893249063675808721iterated = false; ?><?php $v122893249063675808721iterator = $page->items; $v122893249063675808721incr = 0; $v122893249063675808721loop = new stdClass(); $v122893249063675808721loop->length = count($v122893249063675808721iterator); $v122893249063675808721loop->index = 1; $v122893249063675808721loop->index0 = 1; $v122893249063675808721loop->revindex = $v122893249063675808721loop->length; $v122893249063675808721loop->revindex0 = $v122893249063675808721loop->length - 1; ?><?php foreach ($v122893249063675808721iterator as $cars) { ?><?php $v122893249063675808721loop->first = ($v122893249063675808721incr == 0); $v122893249063675808721loop->index = $v122893249063675808721incr + 1; $v122893249063675808721loop->index0 = $v122893249063675808721incr; $v122893249063675808721loop->revindex = $v122893249063675808721loop->length - $v122893249063675808721incr; $v122893249063675808721loop->revindex0 = $v122893249063675808721loop->length - ($v122893249063675808721incr + 1); $v122893249063675808721loop->last = ($v122893249063675808721incr == ($v122893249063675808721loop->length - 1)); ?><?php $v122893249063675808721iterated = true; ?>
<?php if ($v122893249063675808721loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th class="hidden">id</th>
            <th>Диллер</th>
            <th>Водитель</th>
            <th>Владелец</th>
            <th>Модель</th>
            <th>Грузоподъемность</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($cars->del == 0) { ?>
    <tbody>
        <tr>
            <td class="hidden"><?php echo $cars->id; ?></td>
            <td><?php echo $cars->dealer->name; ?></td>
            <td><?php echo $cars->driver->name; ?></td>
            <td><?php echo $cars->owner->name; ?></td>
            <td><?php echo $cars->model; ?></td>
            <td><?php echo $cars->capacity; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('car/edit/' . $cars->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('car/delete/' . $cars->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v122893249063675808721loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('car/index/', '<i class="icon-fast-backward"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('car/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('car/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('car/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v122893249063675808721incr++; } if (!$v122893249063675808721iterated) { ?>
    No companies are recorded
<?php } ?>