<?php foreach (range(1, $parts) as $index) { ?>
    <?php echo $this->tag->linkTo(array('owner/export', 'Экспорт ' . $index, 'class' => 'btn btn-primary')); ?></br>
<?php } ?>