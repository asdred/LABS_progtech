<div>
    <div>
        <h2>Перевозки <?php echo $status; ?></h2>
    </div>
    <div>
        <div style="text-align: left">
            <?php echo $this->tag->form(array('transport/index')); ?>
                <input type="radio" name="interval" value="year">За последний год</inpu><br>
                <input type="radio" name="interval" value="month">За последний месяц</inpu><br>
                <input type="radio" name="interval" value="week">За последний неделю</inpu><br>
                <input type="radio" name="interval" value="day">За последний день</inpu><br>
                <?php echo $this->tag->submitButton(array('Фильтр', 'class' => 'btn btn-primary')); ?>
            </form>
        </div>
        <?php echo $this->tag->linkTo(array('transport/new', 'Создать', 'class' => 'btn btn-primary')); ?>
    </div>
</div>

<?php $v53327775920813352631iterated = false; ?><?php $v53327775920813352631iterator = $page->items; $v53327775920813352631incr = 0; $v53327775920813352631loop = new stdClass(); $v53327775920813352631loop->length = count($v53327775920813352631iterator); $v53327775920813352631loop->index = 1; $v53327775920813352631loop->index0 = 1; $v53327775920813352631loop->revindex = $v53327775920813352631loop->length; $v53327775920813352631loop->revindex0 = $v53327775920813352631loop->length - 1; ?><?php foreach ($v53327775920813352631iterator as $transport) { ?><?php $v53327775920813352631loop->first = ($v53327775920813352631incr == 0); $v53327775920813352631loop->index = $v53327775920813352631incr + 1; $v53327775920813352631loop->index0 = $v53327775920813352631incr; $v53327775920813352631loop->revindex = $v53327775920813352631loop->length - $v53327775920813352631incr; $v53327775920813352631loop->revindex0 = $v53327775920813352631loop->length - ($v53327775920813352631incr + 1); $v53327775920813352631loop->last = ($v53327775920813352631incr == ($v53327775920813352631loop->length - 1)); ?><?php $v53327775920813352631iterated = true; ?>
<?php if ($v53327775920813352631loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th>Номер</th>
            <th>Авто</th>
            <th>Организация</th>
            <th>Склад</th>
            <th>Дата</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($transport->del == 0) { ?>
    <tbody>
        <tr>
            <td><?php echo $transport->id; ?></td>
            <td><?php echo $transport->car->model; ?></td>
            <td><?php echo $transport->organization->name; ?></td>
            <td><?php echo $transport->store->name; ?></td>
            <td><?php echo $transport->date; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('transport/edit/' . $transport->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('transport/delete/' . $transport->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v53327775920813352631loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('transport/index/', '<i class="icon-fast-backward"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('transport/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('transport/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('transport/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v53327775920813352631incr++; } if (!$v53327775920813352631iterated) { ?>
    No companies are recorded
<?php } ?>


