<div>
    <div>
        <h2>Товары <?php echo $status; ?></h2>
    </div>
    <div>
        <div style="text-align: left">
            <?php echo $this->tag->form(array('product/index')); ?>
                <input type="radio" name="filter" value="max">Наибольший вес</inpu><br>
                <input type="radio" name="filter" value="min">Наименьший вес</inpu><br>
                <?php echo $this->tag->submitButton(array('Фильтр', 'class' => 'btn btn-primary')); ?>
            </form>
        </div>
        <?php echo $this->tag->linkTo(array('product/new', 'Создать', 'class' => 'btn btn-primary')); ?>
    </div>
</div>

<?php $v101692840080073026751iterated = false; ?><?php $v101692840080073026751iterator = $page->items; $v101692840080073026751incr = 0; $v101692840080073026751loop = new stdClass(); $v101692840080073026751loop->length = count($v101692840080073026751iterator); $v101692840080073026751loop->index = 1; $v101692840080073026751loop->index0 = 1; $v101692840080073026751loop->revindex = $v101692840080073026751loop->length; $v101692840080073026751loop->revindex0 = $v101692840080073026751loop->length - 1; ?><?php foreach ($v101692840080073026751iterator as $products) { ?><?php $v101692840080073026751loop->first = ($v101692840080073026751incr == 0); $v101692840080073026751loop->index = $v101692840080073026751incr + 1; $v101692840080073026751loop->index0 = $v101692840080073026751incr; $v101692840080073026751loop->revindex = $v101692840080073026751loop->length - $v101692840080073026751incr; $v101692840080073026751loop->revindex0 = $v101692840080073026751loop->length - ($v101692840080073026751incr + 1); $v101692840080073026751loop->last = ($v101692840080073026751incr == ($v101692840080073026751loop->length - 1)); ?><?php $v101692840080073026751iterated = true; ?>
<?php if ($v101692840080073026751loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th class="hidden">id</th>
            <th>Название</th>
            <th>Масса 1 м^3 (кг)</th>
            <th>Тип</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($products->del == 0) { ?>
    <tbody>
        <tr>
            <td class="hidden"><?php echo $products->id; ?></td>
            <td><?php echo $products->name; ?></td>
            <td><?php echo $products->weight; ?></td>
            <td><?php echo $products->producttype->name; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('product/edit/' . $products->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('product/delete/' . $products->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v101692840080073026751loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('product/index/', '<i class="icon-fast-backward"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('product/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('product/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('product/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v101692840080073026751incr++; } if (!$v101692840080073026751iterated) { ?>
    No companies are recorded
<?php } ?>

