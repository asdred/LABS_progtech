<div>
    <div>
        <h2>Грузы</h2>
    </div>
    <div>
        <?php echo $this->tag->linkTo(array('shipment/new', 'Создать', 'class' => 'btn btn-primary')); ?>
    </div>
</div>

<?php $v154886016802310774341iterated = false; ?><?php $v154886016802310774341iterator = $page->items; $v154886016802310774341incr = 0; $v154886016802310774341loop = new stdClass(); $v154886016802310774341loop->length = count($v154886016802310774341iterator); $v154886016802310774341loop->index = 1; $v154886016802310774341loop->index0 = 1; $v154886016802310774341loop->revindex = $v154886016802310774341loop->length; $v154886016802310774341loop->revindex0 = $v154886016802310774341loop->length - 1; ?><?php foreach ($v154886016802310774341iterator as $shipments) { ?><?php $v154886016802310774341loop->first = ($v154886016802310774341incr == 0); $v154886016802310774341loop->index = $v154886016802310774341incr + 1; $v154886016802310774341loop->index0 = $v154886016802310774341incr; $v154886016802310774341loop->revindex = $v154886016802310774341loop->length - $v154886016802310774341incr; $v154886016802310774341loop->revindex0 = $v154886016802310774341loop->length - ($v154886016802310774341incr + 1); $v154886016802310774341loop->last = ($v154886016802310774341incr == ($v154886016802310774341loop->length - 1)); ?><?php $v154886016802310774341iterated = true; ?>
<?php if ($v154886016802310774341loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th class="hidden">id</th>
            <th>Продукт</th>
            <th>Номер перевозки</th>
            <th>Количество (м^3)</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($shipments->del == 0) { ?>
    <tbody>
        <tr>
            <td class="hidden"><?php echo $shipments->id; ?></td>
            <td><?php echo $shipments->product->name; ?></td>
            <td><?php echo $shipments->transportation_id; ?></td>
            <td><?php echo $shipments->amount; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('shipment/edit/' . $shipments->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('shipment/delete/' . $shipments->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v154886016802310774341loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('shipment/index/', '<i class="icon-fast-backward"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('shipment/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('shipment/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('shipment/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v154886016802310774341incr++; } if (!$v154886016802310774341iterated) { ?>
    No companies are recorded
<?php } ?>

