
<?php echo $this->elements->getTabs(); ?>

<div align="center">
    <?php echo $this->getContent(); ?>
</div>
