<div>
    <div>
        <h2>Типы товаров</h2>
    </div>
    <div>
        <?php echo $this->tag->linkTo(array('producttype/new', 'Создать', 'class' => 'btn btn-primary')); ?>
    </div>
</div>

<?php $v174686774239551700691iterated = false; ?><?php $v174686774239551700691iterator = $page->items; $v174686774239551700691incr = 0; $v174686774239551700691loop = new stdClass(); $v174686774239551700691loop->length = count($v174686774239551700691iterator); $v174686774239551700691loop->index = 1; $v174686774239551700691loop->index0 = 1; $v174686774239551700691loop->revindex = $v174686774239551700691loop->length; $v174686774239551700691loop->revindex0 = $v174686774239551700691loop->length - 1; ?><?php foreach ($v174686774239551700691iterator as $producttypes) { ?><?php $v174686774239551700691loop->first = ($v174686774239551700691incr == 0); $v174686774239551700691loop->index = $v174686774239551700691incr + 1; $v174686774239551700691loop->index0 = $v174686774239551700691incr; $v174686774239551700691loop->revindex = $v174686774239551700691loop->length - $v174686774239551700691incr; $v174686774239551700691loop->revindex0 = $v174686774239551700691loop->length - ($v174686774239551700691incr + 1); $v174686774239551700691loop->last = ($v174686774239551700691incr == ($v174686774239551700691loop->length - 1)); ?><?php $v174686774239551700691iterated = true; ?>
<?php if ($v174686774239551700691loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th class="hidden">id</th>
            <th>Название</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($producttypes->del == 0) { ?>
    <tbody>
        <tr>
            <td class="hidden"><?php echo $producttypes->id; ?></td>
            <td><?php echo $producttypes->name; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('producttype/edit/' . $producttypes->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('producttype/delete/' . $producttypes->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v174686774239551700691loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('producttype/index/', '<i class="icon-fast-backward"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('producttype/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('producttype/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('producttype/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v174686774239551700691incr++; } if (!$v174686774239551700691iterated) { ?>
    No companies are recorded
<?php } ?>