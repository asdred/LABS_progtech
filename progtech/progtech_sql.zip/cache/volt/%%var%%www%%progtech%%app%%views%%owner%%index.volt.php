<div>
    <h2>Владельцы</h2>
</div>
<div>
    <?php echo $this->tag->linkTo(array('owner/new', 'Создать', 'class' => 'btn btn-primary')); ?>
</div>

<?php $v82544349354192877091iterated = false; ?><?php $v82544349354192877091iterator = $page->items; $v82544349354192877091incr = 0; $v82544349354192877091loop = new stdClass(); $v82544349354192877091loop->length = count($v82544349354192877091iterator); $v82544349354192877091loop->index = 1; $v82544349354192877091loop->index0 = 1; $v82544349354192877091loop->revindex = $v82544349354192877091loop->length; $v82544349354192877091loop->revindex0 = $v82544349354192877091loop->length - 1; ?><?php foreach ($v82544349354192877091iterator as $owners) { ?><?php $v82544349354192877091loop->first = ($v82544349354192877091incr == 0); $v82544349354192877091loop->index = $v82544349354192877091incr + 1; $v82544349354192877091loop->index0 = $v82544349354192877091incr; $v82544349354192877091loop->revindex = $v82544349354192877091loop->length - $v82544349354192877091incr; $v82544349354192877091loop->revindex0 = $v82544349354192877091loop->length - ($v82544349354192877091incr + 1); $v82544349354192877091loop->last = ($v82544349354192877091incr == ($v82544349354192877091loop->length - 1)); ?><?php $v82544349354192877091iterated = true; ?>
<?php if ($v82544349354192877091loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th class="hidden">id</th>
            <th>И.Фамилия</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($owners->del == 0) { ?>
    <tbody>
        <tr>
            <td class="hidden"><?php echo $owners->id; ?></td>
            <td><?php echo $owners->name; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('owner/edit/' . $owners->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('owner/delete/' . $owners->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v82544349354192877091loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('owner/index/', '<i class="icon-fast-backward"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('owner/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('owner/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('owner/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php echo $this->tag->linkTo(array('owner/export', 'Экспорт', 'class' => 'btn btn-primary')); ?>
<?php } ?>
<?php $v82544349354192877091incr++; } if (!$v82544349354192877091iterated) { ?>
    No companies are recorded
<?php } ?>

