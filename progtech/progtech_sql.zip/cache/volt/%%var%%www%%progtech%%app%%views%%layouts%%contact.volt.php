<?php echo $this->getContent(); ?>
