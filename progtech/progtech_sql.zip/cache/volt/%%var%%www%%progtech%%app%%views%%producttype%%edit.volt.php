
<?php echo $this->tag->form(array('producttype/save', 'role' => 'form')); ?>

<ul class="pager">
    <li class="previous pull-left">
        <?php echo $this->tag->linkTo(array('producttype', '&larr; Назад')); ?>
    </li>
    <li class="pull-right">
        <?php echo $this->tag->submitButton(array('Сохранить', 'class' => 'btn btn-success')); ?>
    </li>
</ul>

<?php echo $this->getContent(); ?>

<h2>Редактирование - Типы продуктов</h2>

<fieldset>

<?php foreach ($form as $element) { ?>
    <?php if (is_a($element, 'Phalcon\Forms\Element\Hidden')) { ?>
<?php echo $element; ?>
    <?php } else { ?>
<div class="form-group">
    <?php echo $element->label(array('class' => 'control-label')); ?>
    <div class="controls">
        <?php echo $element; ?>
    </div>
</div>
    <?php } ?>
<?php } ?>

</fieldset>

</form>
