
<?php echo $this->getContent(); ?>

<div class="profile left">
    <?php echo $this->tag->form(array('invoices/profile', 'id' => 'profileForm', 'onbeforesubmit' => 'return false')); ?>
        <div class="clearfix">
            <label for="name">Логин:</label>
            <div class="input">
                <?php echo $this->tag->textField(array('name', 'size' => '30', 'class' => 'span6')); ?>
                <div class="alert" id="name_alert">
                    <strong>Warning!</strong> Please enter your full name
                </div>
            </div>
        </div>
        <div class="clearfix">
            <label for="email">Email:</label>
            <div class="input">
                <?php echo $this->tag->textField(array('email', 'size' => '30', 'class' => 'span6')); ?>
                <div class="alert" id="email_alert">
                    <strong>Warning!</strong> Please enter your email
                </div>
            </div>
        </div>
        <div class="clearfix">
            <input type="button" value="Изменить" class="btn btn-primary btn-large btn-info" onclick="Profile.validate()">
            &nbsp;
            <?php echo $this->tag->linkTo(array('invoices/index', 'Отменить')); ?>
        </div>
    </form>
</div>