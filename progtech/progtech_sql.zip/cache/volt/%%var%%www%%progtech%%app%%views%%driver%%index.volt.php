<div>
    <div>
        <h2>Водители <?php echo $status; ?></h2>
    </div>
    <div>
        <div style="text-align: left">
            <?php echo $this->tag->form(array('driver/index')); ?>
                <input type="radio" name="filter" value="maxExp">Наиболее опытные</inpu><br>
                <input type="radio" name="filter" value="minExp">Наименее опытные</inpu><br>
                <input type="radio" name="filter" value="maxSal">Наиболее оплачиваемые</inpu><br>
                <input type="radio" name="filter" value="minSal">Наименее оплачиваемые</inpu><br>
                <?php echo $this->tag->submitButton(array('Фильтр', 'class' => 'btn btn-primary')); ?>
            </form>
        </div>
        <?php echo $this->tag->linkTo(array('driver/new', 'Создать', 'class' => 'btn btn-primary')); ?>
    </div>
</div>

<?php $v108041433046829717101iterated = false; ?><?php $v108041433046829717101iterator = $page->items; $v108041433046829717101incr = 0; $v108041433046829717101loop = new stdClass(); $v108041433046829717101loop->length = count($v108041433046829717101iterator); $v108041433046829717101loop->index = 1; $v108041433046829717101loop->index0 = 1; $v108041433046829717101loop->revindex = $v108041433046829717101loop->length; $v108041433046829717101loop->revindex0 = $v108041433046829717101loop->length - 1; ?><?php foreach ($v108041433046829717101iterator as $drivers) { ?><?php $v108041433046829717101loop->first = ($v108041433046829717101incr == 0); $v108041433046829717101loop->index = $v108041433046829717101incr + 1; $v108041433046829717101loop->index0 = $v108041433046829717101incr; $v108041433046829717101loop->revindex = $v108041433046829717101loop->length - $v108041433046829717101incr; $v108041433046829717101loop->revindex0 = $v108041433046829717101loop->length - ($v108041433046829717101incr + 1); $v108041433046829717101loop->last = ($v108041433046829717101incr == ($v108041433046829717101loop->length - 1)); ?><?php $v108041433046829717101iterated = true; ?>
<?php if ($v108041433046829717101loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th class="hidden">id</th>
            <th>И.Фамилия</th>
            <th>Стаж</th>
            <th>Зарплата</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($drivers->del == 0) { ?>
    <tbody>
        <tr>
            <td class="hidden"><?php echo $drivers->id; ?></td>
            <td><?php echo $drivers->name; ?></td>
            <td><?php echo $drivers->experience; ?></td>
            <td><?php echo $drivers->salary; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('driver/edit/' . $drivers->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('driver/delete/' . $drivers->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v108041433046829717101loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('driver/index/', '<i class="icon-fast-backward"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('driver/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('driver/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('driver/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v108041433046829717101incr++; } if (!$v108041433046829717101iterated) { ?>
    No companies are recorded
<?php } ?>


