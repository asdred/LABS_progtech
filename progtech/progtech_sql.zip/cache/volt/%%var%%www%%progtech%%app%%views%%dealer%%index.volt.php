<div>
    <div>
        <h2>Диллеры</h2>
    </div>
    <div>
        <?php echo $this->tag->linkTo(array('dealer/new', 'Создать', 'class' => 'btn btn-primary')); ?>
    </div>
</div>

<?php $v50207451699483237431iterated = false; ?><?php $v50207451699483237431iterator = $page->items; $v50207451699483237431incr = 0; $v50207451699483237431loop = new stdClass(); $v50207451699483237431loop->length = count($v50207451699483237431iterator); $v50207451699483237431loop->index = 1; $v50207451699483237431loop->index0 = 1; $v50207451699483237431loop->revindex = $v50207451699483237431loop->length; $v50207451699483237431loop->revindex0 = $v50207451699483237431loop->length - 1; ?><?php foreach ($v50207451699483237431iterator as $dealers) { ?><?php $v50207451699483237431loop->first = ($v50207451699483237431incr == 0); $v50207451699483237431loop->index = $v50207451699483237431incr + 1; $v50207451699483237431loop->index0 = $v50207451699483237431incr; $v50207451699483237431loop->revindex = $v50207451699483237431loop->length - $v50207451699483237431incr; $v50207451699483237431loop->revindex0 = $v50207451699483237431loop->length - ($v50207451699483237431incr + 1); $v50207451699483237431loop->last = ($v50207451699483237431incr == ($v50207451699483237431loop->length - 1)); ?><?php $v50207451699483237431iterated = true; ?>
<?php if ($v50207451699483237431loop->first) { ?>
<table class="table table-bordered table-striped" id="table-info" align="center">
    <thead>
        <tr>
            <th class="hidden">id</th>
            <th>Название</th>
            <th colspan="2"></th>
        </tr>
    </thead>
<?php } ?>
<?php if ($dealers->del == 0) { ?>
    <tbody>
        <tr>
            <td class="hidden"><?php echo $dealers->id; ?></td>
            <td><?php echo $dealers->name; ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('dealer/edit/' . $dealers->id, '<i class="glyphicon glyphicon-edit"></i> Изменить', 'class' => 'btn btn-default')); ?></td>
            <td width="7%"><?php echo $this->tag->linkTo(array('dealer/delete/' . $dealers->id, '<i class="glyphicon glyphicon-remove"></i> Удалить', 'class' => 'btn btn-default')); ?></td>
        </tr>
    </tbody>
<?php } ?>
<?php if ($v50207451699483237431loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?php echo $this->tag->linkTo(array('dealer/index/', '<i class="icon-fast-backward"></i> Первая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('dealer/index/' . $page->before, '<i class="icon-step-backward"></i> Предыдущая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('dealer/index/' . $page->next, '<i class="icon-step-forward"></i> Следующая', 'class' => 'btn btn-default')); ?>
                    <?php echo $this->tag->linkTo(array('dealer/index/' . $page->last, '<i class="icon-fast-forward"></i> Последняя', 'class' => 'btn btn-default')); ?>
                    <span class="help-inline"><?php echo $page->current; ?>/<?php echo $page->total_pages; ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v50207451699483237431incr++; } if (!$v50207451699483237431iterated) { ?>
    No companies are recorded
<?php } ?>